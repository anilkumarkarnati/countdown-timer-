let countdownInterval;

function startCountdown() {
  const userTime = document.getElementById('datetime-picker').value;
  const targetDate = new Date(userTime).getTime();

  clearInterval(countdownInterval); // clear previous intervals if any

  const countdownEl = document.getElementById('countdown');
  countdownEl.style.display = "block"; // show countdown again if hidden
  countdownEl.classList.add('blink');  // start blinking

  document.getElementById("message").textContent = ""; // clear message

  countdownInterval = setInterval(() => {
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (distance < 0) {
      clearInterval(countdownInterval);
      document.getElementById("message").textContent = "Time's up!";
      countdownEl.style.display = "none";
      countdownEl.classList.remove('blink'); // stop blinking
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById('days').textContent = days.toString().padStart(2, '0');
    document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
    document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
    document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
  }, 1000);
}
